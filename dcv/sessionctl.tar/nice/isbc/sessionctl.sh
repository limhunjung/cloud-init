#!/bin/bash
CFGFILE=/opt/nice/isbc/sessionctl.cfg
TMPCHECK=/tmp/$USER-session.txt

while [ 1 ]
do
    CHKIDLE=$(/opt/nice/isbc/getidle.run)
    if [ -e $CFGFILE ]
    then
	LOGDIR=$(grep -i '^LOGDIR=' $CFGFILE | awk -F = '{print $2}')
	LIMITTIME=$(grep -i '^IDLETIMELIMIT=' $CFGFILE | awk -F = '{print $2}')
	WORKSTART=$(grep -i '^BEGINTIME=' $CFGFILE | awk -F = '{print $2}')
	WORKEND=$(grep -i '^ENDTIME=' $CFGFILE | awk -F = '{print $2}')
	CHKINTERVAL=$(grep -i '^CHKINTERVAL=' $CFGFILE | awk -F = '{print $2}')
    fi
    if [ ! -n "$LOGDIR" ] || [ "$LOGDIR" == "" ]
    then
	LOGDIR=/opt/nice/isbc/log
    fi
    if [ ! -n "$LIMITTIME" ] || [ "$LIMITTIME" == "" ]
    then
	LIMITTIME=24
    fi
    if [ ! -n "$WORKSTART" ] || [ "$WORKSTART" == "" ]
    then
	WORKSTART=9
    fi
    if [ ! -n "$WORKEND" ] || [ "$WORKEND" == "" ]
    then
	WORKEND=18
    fi
    if [ ! -n "$CHKINTERVAL" ] || [ "$CHKINTERVAL" == "" ]
    then
	CHKINTERVAL=60
    fi

    #LIMITSEC=$(expr ${LIMITTIME} \* 60 \* 60)
    LIMITSEC=$(expr ${LIMITTIME} \* 300) 
    DAY=$(date +%w)
    TIME=$(date +%H)
    TODAY=$(date "+%Y-%m-%d")
    NOW=$(date "+%Y-%m %d-%H:%M")
    echo "$NOW Begin time is $WORKSTART and End time is $WORKEND. LIMIT Seconds is $LIMITSEC. Check every $CHKINTERVAL seconds...logging to ${LOGDIR}" 
    echo "$NOW Begin time is $WORKSTART and End time is $WORKEND. LIMIT Seconds is $LIMITSEC. Check every $CHKINTERVAL seconds...logging to ${LOGDIR}" >> $TMPCHECK
    HOLIDAY=/opt/nice/isbc/sessionctl_holiday.cfg
    DAYCHECK=/tmp/$USER-checkday.txt

    if [ ${CHKIDLE} -lt 0 ]
    #if [ ${CHKIDLE} < 0 ]
    then
	exit
    fi

    cat $HOLIDAY | grep $TODAY | grep -v "#" > $DAYCHECK
    if [ -s $DAYCHECK ]
    then
        echo "$NOW Today is Holiday" >> $TMPCHECK
    else
    case $DAY in
	6 | 7 ) 
	    ;;
	0 ) 
	    ;;
	* )
	    if	[ $TIME -ge ${WORKSTART} ] && [ $TIME -lt ${WORKEND} ]
	    then
		if [ ${CHKIDLE} -gt ${LIMITSEC} ]
		then
			echo Sessionctl will close this session : $DCV_SESSION_ID
                        echo $NOW Sessionctl will close this session : $DCV_SESSION_ID >> $TMPCHECK
#			for pid in $(ps -Ao %p%c%U | grep $USER | sed '/ksmserver/!d; s/ *\([0-9]*\) *.*/\1/g'); do
#			        DISPLAYLIST="$(tr '\0' '\n' < /proc/$pid/environ | grep DISPLAY= |tail -n 1| cut -d"=" -f2- )"
#        			if [ "$DISPLAY" == "$DISPLAYLIST" ]
#        			then
#         		       		ADDRESS="$(tr '\0' '\n' < /proc/$pid/environ | grep DBUS_SESSION_BUS_ADDRESS |  cut -d"=" -f2-)"
#                			/usr/bin/qdbus --address "$ADDRESS" org.kde.ksmserver /KSMServer org.kde.KSMServerInterface.logout 0 0 2
#					sleep 10
#					kill -9 $pid
					#rm -rf /tmp/akonadi-$USER.*
					#rm -rf /tmp/kde-$USER
					#rm -rf /tmp/ksocket-$USER
					#rm -rf /var/tmp/kdecache-$USER
#       			fi
#			done
                        echo $NOW " : Terminate $USER session for idle timeout" $CHKIDLE "seconds." >> $TMPCHECK
	      	        echo $(date) " : Terminate $USER session for idle timeout" $CHKIDLE "seconds." $HOSTNAME $DISPLAY $DCV_SESSION_ID >> $LOGDIR/$(date +%Y)-$USER.timeout.log
			dcv close-session $DCV_SESSION_ID
		    exit
		fi
	    fi
	    ;;
    esac
    fi
    if [ ! ${CHKIDLE} -ge 0  ]
    then
	exit
    fi
    sleep $CHKINTERVAL

    #Check Session
    #getppid=$(ps -f $(echo $$) | tail -n 1 | awk '{print $3}')
    #TARGET=$(ps -f $getppid | grep dcv | wc -l)
    #if [ ${TARGET} -lt 0 ];
    #    then
    #    echo "Sessionctl Exited"
    #    exit
    #fi

done

