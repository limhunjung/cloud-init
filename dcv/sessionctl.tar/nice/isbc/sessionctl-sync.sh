#!/bin/bash
#GN=`46 61`
GN=`seq 46 61`
#FILE="sessionctl.sh sessionctl.cfg sessionctl_holiday.cfg"
FILE="sessionctl-dcv-v0.5.sh sessionctl sessionctl.cfg sessionctl_holiday.cfg sessionctl_except.sh"
for i in $GN
 #do scp /opt/nice/isbc/sessionctl* gn$i:/opt/nice/isbc/ 
 do
   for x in $FILE
   do rsync -ave ssh /opt/nice/isbc/$x gn$i:/opt/nice/isbc/
   done
#    scp /opt/nice/isbc/sessionctl.cfg dcv2021-$i:/opt/nice/isbc/ 
#    scp /opt/nice/isbc/sessionctl_holiday.cfg dcv2021-$i:/opt/nice/isbc/ 
done

